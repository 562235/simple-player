﻿#include "video.h"
#include "ui_video.h"



video::video(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::video)
{
    ui->setupUi(this);
    //视频界面初始化
    init_video();
}

video::~video()
{
    delete [] video_pl;
    delete [] m_t;
    delete [] gesture_timer;
    delete ui;
}

//视频界面的初始化
void video::init_video()
{
    //设置背景图片
    QPixmap background("/myvideo/video_background.jpg");
    //设置图片大小
    background.scaled(this->width(), this->height());
    //显示图片
    ui->background->setPixmap(background);

    /***********视频界面的初始化**************/

    //已进入到当前视频界面，应该从当前目录中获取所有的视频文件，显示到listWidget
    find_video_file("/myvideo/", QStringList() << "*.avi");
    for(int i=0; i<video_files.size(); i++)
    {
        //tmp 视频名及后缀
        QString tmp = video_files.at(i);
        tmp.remove(0, tmp.lastIndexOf("/")+1);
        //path_tmp 小图标获取路径
        /*QString path_tmp = tmp;
        path_tmp =  path_tmp.remove(".avi") + ".jpg";
        path_tmp = "/myvideo/" + path_tmp;
        QIcon ic(path_tmp);

        QListWidgetItem *it  = new QListWidgetItem(ic, tmp);*/
        ui->listWidget->addItem(tmp);
    }

    //播放器进程
    video_pl = new QProcess(this);
    //关联mplay播放器的可读信号
    connect(video_pl, SIGNAL(readyRead()), this, SLOT(read_show()));

    /***************手势识别模块****************/
    gesture_fd = open("/dev/IIC_drv", O_RDWR);
    if(gesture_fd >= 0)
    {
        qDebug() << " video gesture open succes" << endl;
    }

    //手势识别定时器
    gesture_timer = new QTimer(this);//关联手势识别定时器
    connect(gesture_timer, SIGNAL(timeout()), this, SLOT(gesture()));
    //打开定时器，监控手势模块
    gesture_timer->start(100);

    //设置进度条的属性
    ui->horizontalSlider->setMaximum(100);
    ui->horizontalSlider->setValue(0);
    ui->listWidget->hide();
    button_highlight();//一进来up键应该高亮
}
//按键正常状态
void video::button_common()
{
    if(selector == 0)
    {
        ui->up->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 0);border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));//音量+正常
    }
    else if(selector == 1)
    {
        ui->hou->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 0);border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));//快退正常
    }
    else if(selector == 2)
    {
        ui->stop_or_continue->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 0);border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));//暂停正常
    }
    else if(selector == 3)
    {
        ui->qian->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 0);border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));//快进正常
    }
    else if(selector == 4)
    {
        ui->down->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 0);border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));//音量-正常
    }
}
//按键高亮状态
void video::button_highlight()
{
    if(selector == 0)
    {
        ui->up->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                     "padding:2px 4px;"));//音量+高亮
    }
    else if(selector == 1)
    {
        ui->hou->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                 "padding:2px 4px;"));//快退高亮
    }
    else if(selector == 2)
    {
        ui->stop_or_continue->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                              "padding:2px 4px;"));//暂停高亮
    }
    else if(selector == 3)
    {
        ui->qian->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                  "padding:2px 4px;"));//快进高亮
    }
    else if(selector == 4)
    {
        ui->down->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                  "padding:2px 4px;"));//音量-高亮
    }
}
//手势处理函数
void video::gesture()
{
    char data = 0;
    read(gesture_fd, &data, 1);//获取手势识别模块返回的数据
    if(data>=1 && data<=9)//判断当前是什么手势
    {
        qDebug()  << "video_data:" << (int)data << endl;
        switch(data)
        {
            /***********手势向上时，执行对应的点击函数***********/
            case 1:
            if(selector==0)
                on_up_clicked();                        //音量+
            else if(selector==1)
               on_hou_clicked();                        //快退10s
            else if(selector==2)
                on_stop_or_continue_clicked();          //暂停/继续
            else if(selector==3)
                on_qian_clicked();                      //快进10s
            else if(selector==4)
                on_down_clicked();                      //音量-
            else if(selector==5)                        //切换选中的视频
            {
                if(video_selector==0)                   //如果选中项等于第一项，回到最后
                {
                    video_selector = video_files.size()-1;
                    ui->listWidget->setCurrentRow(video_selector);  //列表中的视频名称高亮
                    break;
                }
                video_selector--;
                ui->listWidget->setCurrentRow(video_selector);      //列表中的视频名称高亮
            }
            break;
            /***********手势向下***********/
            case 2:
            if(selector==5)                             //如果是选中了视频列表，则是上下切换选项
            {
                if(video_selector==video_files.size()-1)//如果选中项等于视频总数时，回到第一项
                {
                    video_selector = 0;
                    ui->listWidget->setCurrentRow(video_selector);  //列表中的视频名称高亮
                    break;
                }
                video_selector++;
                ui->listWidget->setCurrentRow(video_selector);      //列表中的视频名称高亮
                break;
            }
            //如果不是选中了视频列表，向下是退出本界面,如果进程正在运行,结束播放器后再退出
            if(video_pl->state() == QProcess::Running)
            {
                //结束播放器
                qDebug() << "Running" << endl;
                video_pl->write("quit \n");
                //父窗体展示，发送信号
                this->parentWidget()->show();
                emit(video_quit("video"));
                //本窗体手势定时器停止
                gesture_timer->stop();
                //关闭本窗体
                this->close();
            }
            //如果进程没有运行,直接退出
            else if(video_pl->state() == QProcess::NotRunning)
            {
                qDebug() << "NotRunning" << endl;
                //父窗体展示，发送信号
                this->parentWidget()->show();
                emit(video_quit("video"));
                //本窗体手势定时器停止
                gesture_timer->stop();
                //关闭本窗体
                this->close();
            }
            break;
            /***********手势向左***********/
            case 3:
            button_common();//原先的按钮恢复正常
            selector--;
            if(selector < 0)
                selector = 5;
            if(selector == 5)
            {
                ui->listWidget->show();
                ui->listWidget->setCurrentRow(video_selector);//列表中的视频名称高亮
            }
            else
                ui->listWidget->hide();
            button_highlight();//指定的按钮高亮
            break;
            /***********手势向右***********/
            case 4:
            button_common();//原先的按钮恢复正常
            selector++;
            if(selector > 5)
                selector = 0;
            if(selector == 5)//如果选中视频列表则显示出来
            {
                ui->listWidget->show();
                ui->listWidget->setCurrentRow(video_selector);//列表中的视频名称高亮
            }
            else
                ui->listWidget->hide();
            button_highlight();//指定的按钮高亮
            break;
            /***********手势向前，播放选中的音乐***********/
            case 5:
            play_video();//播放选中的音乐
            ui->listWidget->hide();
            break;
            /****************手势晃动*******************/
            case 9:
            full_screen_fun();//全屏播放
            break;
            default:break;
        }

    }
}
//切换全屏
void video::full_screen_fun ()
{
    //暂停定时器
    m_t->stop();
    gesture_timer->stop();
    //暂停当前播放器
    video_pl->kill();
    video_pl->waitForFinished();
    //在新窗体中全屏播放
    full_screen *full_win = new full_screen(this);
    //传给子窗体 播放路径和时间
    full_win->show();
    full_win->full_play_time(play_path, ui->horizontalSlider->value(), len);
    //隐藏本窗体
    this->hide();
}

//遍历目录 找到所有的视频文件
void video::find_video_file(QString path, QStringList filters)
{
    QDir dir(path);
    //搜索当前目录符合条件的文件
    foreach (QString file, dir.entryList(filters, QDir::Files))
        video_files += path + '/' + file;

    //搜索当前目录的子目录符合条件的文件
    foreach (QString subdir, dir.entryList(QDir::AllDirs | QDir::NoDotAndDotDot))
    {
        find_video_file(path + '/' + subdir, filters);
    }
}

//读取播放器返回的数据
void video::read_show()
{
    QString tmp = video_pl->readAll();
    read_msg = tmp;
    //如果是视频总长度,则保存len
    if(tmp.indexOf("LENGTH") >= 0)
    {
        len = tmp.remove(0, tmp.lastIndexOf("=")+1).remove("\n").toFloat();
    }
    //如果是当前时间，则保存read_msg
    else if(read_msg.indexOf("TIME_POSITION") >= 0)
    {
        read_msg.remove(0, read_msg.lastIndexOf("=")+1).remove("\n");
    }
    int num = (int)(read_msg.toFloat()*100/len);
    ui->horizontalSlider->setValue(num);
    qDebug() << "video:" << tmp << endl;
}
//全屏后继续播放
void video::contiue_play(int time)
{
    qDebug() << "contiue_play 1" << endl;
    ui->horizontalSlider->show();           //更新进度条
    QString start_tmp = QString("mplayer -slave -quiet -zoom -x 800 -y 350 %1").arg(play_path);
    video_pl->start(start_tmp);             //播放视频
    m_t->start(1000);                       //打开定时器，继续获取视频进度
    gesture_timer->start(100);              //打开手势识别定时器
    QString tmp = QString("seek %1 1 \n").arg(time);
    video_pl->write(tmp.toUtf8().data());   //更新视频进度，对接全屏时播放进度
    qDebug() << "contiue_play 2" << endl;
}
//每秒获取视频的进度
void video::video_plan()
{
    //打印出在文件的当前位置用秒表示，采用浮点数
    video_pl->write("get_time_pos \n");
}

//暂停/继续按钮
void video::on_stop_or_continue_clicked()
{
    //暂停
    if(flag == 0)
    {
        m_t->stop();
        video_pl->write("pause \n");
        flag++;
        ui->stop_or_continue->setText("PLAY");
    }
    //播放
    else if(flag == 1)
    {
        m_t->start(1000);
        video_pl->write("pause \n");
        flag--;
        ui->stop_or_continue->setText("STOP");
    }

}

//播放函数，开启定时器，每秒获取视频进度
void video::play_video()
{
    play_path = ui->listWidget->item(video_selector)->text();
    play_path = "/myvideo/" + play_path;
    //如果进程没有运行,直接开始运行
    if(video_pl->state() == QProcess::NotRunning)
    {
        //打开mplay播放器
        QString start_tmp = QString("mplayer -slave -quiet -zoom -x 800 -y 350 %1").arg(play_path);
        video_pl->start(start_tmp);
        //获取视频总长度
        video_pl->write("get_time_length  \n");
        //定时器 每秒获取视频进度
        m_t = new QTimer(this);
        connect(this->m_t, SIGNAL(timeout()), this, SLOT(video_plan()));
        this->m_t->start(1000);
    }
    //如果进程正在运行
    else if(video_pl->state() == QProcess::Running)
    {
        //暂停定时器
        m_t->stop();
        //杀死进程
        video_pl->kill();
        //回收资源
        video_pl->waitForFinished();
        //打开mplay播放器
        QString start_tmp = QString("mplayer -slave -quiet -zoom -x 800 -y 350 %1").arg(play_path);
        video_pl->start(start_tmp);
        //获取视频总长度
        video_pl->write("get_time_length  \n");
        m_t->start(1000);
    }
}
//增大音量
void video::on_up_clicked()
{
    if(volume == 100)
    {
        qDebug() << "温馨提示,音量以增大至100" << endl;
    }
    else
    {
        volume += 10;
        QString msg = QString("volume %1 1\n").arg(volume);
        video_pl->write(msg.toUtf8().data());
    }

}
//减小音量
void video::on_down_clicked()
{
    if(volume == 0)
    {
        qDebug() << "温馨提示,音量以减小至0" << endl;
    }
    else
    {
        volume -= 10;
        QString msg = QString("volume %1 1\n").arg(volume);
        video_pl->write(msg.toUtf8().data());
    }
}

//快退10s
void video::on_hou_clicked()
{
    video_pl->write("seek -10 \n");
}
//快进10s
void video::on_qian_clicked()
{
    video_pl->write("seek +10 \n");
}

