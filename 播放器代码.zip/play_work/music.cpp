﻿#include "music.h"
#include "ui_music.h"

music::music(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::music)
{
    ui->setupUi(this);
    //初始化
    init();
}

music::~music()
{
    delete [] music_pl;
    delete [] m_t;
    delete [] gesture_timer;
    delete ui;
    qDebug() << "music_recede" << endl;
}
//初始化
void music::init()
{
    //设置背景图片
    QPixmap background("/mymusic/music_bagrod.jpg");
    //设置图片大小
    background.scaled(this->width(), this->height());
    //显示图片
    ui->background->setPixmap(background);

    //已进入到当前音乐界面，应该从/IOT目录中获取所有的音乐文件，显示到listWidget(C:/Users/62307/Videos/Captures)
    find_music_file("/mymusic/", QStringList() << "*.mp3");
    for(int i=0; i<music_files.size(); i++)
    {
        QString tmp = music_files.at(i);
        tmp.remove(0, tmp.lastIndexOf("/")+1);
        ui->listWidget->addItem(tmp);
    }
    //已进入到当前音乐界面，应该从/IOT目录中获取所有的歌词文件
    find_music_lrc("/mymusic/", QStringList() << "*.lrc");
    //已进入到当前音乐界面，应该从/IOT目录中获取所有的图片文件
    find_music_backpic("/mymusic/", QStringList() << "*.jpg");

    //播放器进程
    music_pl = new QProcess(this);
    //关联mplay播放器的可读信号
    connect(music_pl, SIGNAL(readyRead()), this, SLOT(read_data()));

    /****************手势识别模块************************/
    gesture_fd = open("/dev/IIC_drv", O_RDWR);
    if(gesture_fd >= 0)
    {
        qDebug() << "music gesture open succes" << endl;
    }

    //手势识别定时器
    gesture_timer = new QTimer(this);
    //关联手势识别定时器
    connect(gesture_timer, SIGNAL(timeout()), this, SLOT(gesture()));
    //打开定时器，监控手势模块
    gesture_timer->start(100);

    //设置进度条的属性
    ui->horizontalSlider->setMaximum(100);
    ui->horizontalSlider->setValue(0);
    ui->listWidget->hide();

    button_highlight();//一进来up键应该高亮
}
//具体的手势识别函数
void music::gesture()
{
    char data = 0;
    read(gesture_fd, &data, 1);//获取手势识别模块返回的数据
    if(data>=1 && data<=9)//判断当前是什么手势
    {
        qDebug()  << "music_data:" << (int)data << endl;
        switch(data)
        {
            /*************手势向上时，执行对应的点击函数****************/
            case 1:
            if(selector==0)
                on_up_clicked();//音量+
            else if(selector==1)
               on_hou_clicked();//快退10s
            else if(selector==2)
                on_stop_or_continue_clicked();//暂停/继续
            else if(selector==3)
                on_qian_clicked();//快进10s
            else if(selector==4)
                on_down_clicked();//音量-
            else if(selector==5)//切换选中的音乐
            {
                if(music_selector==0)//如果选中项等于第一项，回到最后
                {
                    music_selector = music_files.size()-1;
                    ui->listWidget->setCurrentRow(music_selector);//列表中的音乐名称高亮
                    break;
                }
                music_selector--;
                ui->listWidget->setCurrentRow(music_selector);//列表中的音乐名称高亮
            }
            break;
            /*********************手势向下********************/
            case 2:
            if(selector==5)//如果是选中了音乐列表，则是上下切换选项
            {
                if(music_selector==music_files.size()-1)//如果选中项等于音乐总数时，回到第一项
                {
                    music_selector = 0;
                    ui->listWidget->setCurrentRow(music_selector);//列表中的音乐名称高亮
                    break;
                }
                music_selector++;
                ui->listWidget->setCurrentRow(music_selector);//列表中的音乐名称高亮
                break;
            }
            //如果不是选中了音乐列表，向下是退出本界面,如果进程正在运行,结束播放器后再退出
            if(music_pl->state() == QProcess::Running)
            {
                //结束播放器
                qDebug() << "Running" << endl;
                music_pl->write("quit \n");
                //父窗体展示，发送信号
                gesture_timer->stop();
                this->parentWidget()->show();
                emit(music_quit("music"));
                //关闭本窗体
                this->close();
            }
            //如果进程没有运行,直接退出
            else if(music_pl->state() == QProcess::NotRunning)
            {
                qDebug() << "NotRunning" << endl;
                //父窗体展示，发送信号
                this->parentWidget()->show();
                emit(music_quit("music"));
                //本窗体手势识别定时器停止工作
                gesture_timer->stop();
                //关闭本窗体
                this->close();
            }
            break;
            /*********************手势向左**********************/
            case 3:
            button_common();//原先的按钮恢复正常
            selector--;
            if(selector < 0)
                selector = 5;
            if(selector == 5)
            {
                ui->listWidget->show();
                ui->listWidget->setCurrentRow(music_selector);//列表中的音乐名称高亮
            }
            else
                ui->listWidget->hide();
            button_highlight();//指定的按钮高亮
            break;
            /**************************手势向右***********************/
            case 4:
            button_common();//原先的按钮恢复正常
            selector++;
            if(selector > 5)
                selector = 0;
            if(selector == 5)//如果选中音乐列表则显示出来
            {
                ui->listWidget->show();
                ui->listWidget->setCurrentRow(music_selector);//列表中的音乐名称高亮
            }
            else
                ui->listWidget->hide();
            button_highlight();//指定的按钮高亮
            break;
            //手势向前，播放选中的音乐
            case 5:
            play_musci();//播放选中的音乐
            ui->listWidget->hide();
            break;
            default:break;
        }

    }
}
//按钮正常状态
void music::button_common()
{
    if(selector == 0)
    {
        ui->up->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 0);border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));//音量+正常
    }
    else if(selector == 1)
    {
        ui->hou->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 0);border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));//快退正常
    }
    else if(selector == 2)
    {
        ui->stop_or_continue->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 0);border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));//暂停正常
    }
    else if(selector == 3)
    {
        ui->qian->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 0);border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));//快进正常
    }
    else if(selector == 4)
    {
        ui->down->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 0);border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));//音量-正常
    }
}
//按钮高亮状态
void music::button_highlight()
{
    if(selector == 0)
    {
        ui->up->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                     "padding:2px 4px;"));//音量+高亮
    }
    else if(selector == 1)
    {
        ui->hou->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                 "padding:2px 4px;"));//快退高亮
    }
    else if(selector == 2)
    {
        ui->stop_or_continue->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                              "padding:2px 4px;"));//暂停高亮
    }
    else if(selector == 3)
    {
        ui->qian->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                  "padding:2px 4px;"));//快进高亮
    }
    else if(selector == 4)
    {
        ui->down->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                  "padding:2px 4px;"));//音量-高亮
    }
}
//播放选中的音乐
void music::play_musci()
{
    QString tmp_path = ui->listWidget->item(music_selector)->text();
    play_path = "/mymusic/" + tmp_path;
    tmp_path = tmp_path.remove(".mp3");
    //遍历歌词列表music_lrc，找到对应的歌词文件
    for(int i=0; i<music_lrc.size(); i++)
    {
        if(music_lrc.at(i).indexOf(tmp_path)>=0)
        {
            lrc_path = music_lrc.at(i);
            break;
        }
    }
    //遍历歌曲图片列表music_pic，找到对应的歌曲图片
    for(int i=0; i<music_pic.size(); i++)
    {
        //找到以后，显示图片
        if(music_pic.at(i).indexOf(tmp_path)>=0)
        {
            pic_path = music_pic.at(i);
            //设置背景图片
            QPixmap background(pic_path);
            //设置图片大小
            background.scaled(this->width(), this->height());
            //显示图片
            ui->background->setPixmap(background);
            break;
        }
    }

    //判断原来的音乐是否在 播放
    if(music_pl->state() == QProcess::NotRunning)
    {
        //创建一个进程，打开mplay播放器
        QString start_tmp = QString("mplayer -slave -quiet -zoom -x 800 -y 370 %1").arg(play_path);
        music_pl->start(start_tmp);
        //获取歌词数据到 lrc_data中了
        gain_lrc_data();
        //获取视频总长度
        music_pl->write("get_time_length  \n");
        //开启定时器，准备定位歌词
        m_t = new QTimer(this);
        connect(this->m_t, SIGNAL(timeout()), this, SLOT(music_plan()));
        this->m_t->start(1000);
    }
    else if(music_pl->state() == QProcess::Running)
    {
        //暂停定时器
        m_t->stop();
        //杀死进程
        music_pl->kill();
        //回收资源
        music_pl->waitForFinished();
        //打开mplay播放器
        QString start_tmp = QString("mplayer -slave -quiet -zoom -x 800 -y 370 %1").arg(play_path);
        music_pl->start(start_tmp);
        //获取歌词数据到 lrc_data中
        gain_lrc_data();
        //获取视频总长度
        music_pl->write("get_time_length  \n");
        m_t->start(1000);

    }

}

//遍历目录 找到所有的音乐文件
void music::find_music_file(QString path, QStringList filters)
{
    QDir dir(path);
    //搜索当前目录符合条件的文件
    foreach (QString file, dir.entryList(filters, QDir::Files))
        music_files += path + '/' + file;

    //搜索当前目录的子目录符合条件的文件
    foreach (QString subdir, dir.entryList(QDir::AllDirs | QDir::NoDotAndDotDot))
    {
        find_music_file(path + '/' + subdir, filters);
    }

}
//遍历目录 找到所有的歌词文件
void music::find_music_lrc(QString path, QStringList filters)
{
    QDir dir(path);
    //搜索当前目录符合条件的文件
    foreach (QString file, dir.entryList(filters, QDir::Files))
        music_lrc += path + '/' + file;

    //搜索当前目录的子目录符合条件的文件
    foreach (QString subdir, dir.entryList(QDir::AllDirs | QDir::NoDotAndDotDot))
    {
        find_music_file(path + '/' + subdir, filters);
    }

}
//寻找指定目录中的所有歌词对应的图片文件
void music::find_music_backpic(QString path, QStringList filters)
{
    QDir dir(path);
    //搜索当前目录符合条件的文件
    foreach (QString file, dir.entryList(filters, QDir::Files))
        music_pic += path + '/' + file;

    //搜索当前目录的子目录符合条件的文件
    foreach (QString subdir, dir.entryList(QDir::AllDirs | QDir::NoDotAndDotDot))
    {
        find_music_file(path + '/' + subdir, filters);
    }
}
//到指定的歌词文件中，获取正确的歌词数据
void music::gain_lrc_data()
{
    //打开文件夹读取文件中的内容
    QFile file(lrc_path);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    while (!file.atEnd())
    {
        QString line = file.readLine();
       //形成歌词列表
       lrc_data.append(line);
    }

}
//将music_time转换成需要的格式 [00:00
void music::gain_time_now()
{
    int fen = 0;
    int miao = 0;
    for(;music_time.toDouble()>=60;)
    {
        fen++;
        music_time = QString::number(music_time.toDouble()-60);
    }
    miao=music_time.toFloat();
    if(fen<=10 && miao<10)
    {
        timenow = QString("[0%1:0%2").arg(fen).arg(miao);
    }
    else if (fen<10 && miao>=10)
    {
        timenow = QString("[0%1:%2").arg(fen).arg(miao);
    }
}


//每秒发送获取歌曲当前时间和实时显示歌词
void music::music_plan()
{
    //获取歌曲当前时间
    music_pl->write("get_time_pos \n");
    //得到真正需要的时间timenow
    gain_time_now();
    //显示歌词
    for(int i=0; i<lrc_data.size(); i++)
    {
        //删除掉时间后再显示
        if(lrc_data.at(i).indexOf(timenow)>=0)
        {
            QString ge_tmp = lrc_data.at(i);
            ge_tmp.remove(0, ge_tmp.lastIndexOf("]")+1);
            ui->gechi->setText(ge_tmp);
            break;
        }
    }
}
//读取播放器返回的数据
void music::read_data()
{
    QString tmp = music_pl->readAll();
    //总时间
    if(tmp.indexOf("LENGTH") >= 0)
    {
        len = tmp.remove(0, tmp.lastIndexOf("=")+1).remove("\n").toFloat();
    }
    //当前时间
    if(tmp.indexOf("TIME_POSITION")>=0)
    {
        music_time =  tmp.remove(0, tmp.lastIndexOf("=")+1).remove("\n");
    }
    int data = (int)(music_time.toFloat()*100/len);
    ui->horizontalSlider->setValue(data);
    qDebug() << tmp << endl;
}
//音量+
void music::on_up_clicked()
{
    if(volume == 100)
    {
        QMessageBox::warning(this,tr("温馨提示"),tr("音量以增大至100"));
    }
    else
    {
        volume += 10;
        QString msg = QString("volume %1 1\n").arg(volume);
        music_pl->write(msg.toUtf8().data());
    }
}
//音量-
void music::on_down_clicked()
{
    if(volume == 0)
    {
        QMessageBox::warning(this,tr("温馨提示"),tr("音量以减小至0"));
    }
    else
    {
        volume -= 10;
        QString msg = QString("volume %1 1\n").arg(volume);
        music_pl->write(msg.toUtf8().data());
    }
}
//快进 10s
void music::on_qian_clicked()
{
    music_pl->write("seek 10 \n");
}

//快退 10s
void music::on_hou_clicked()
{
    music_pl->write("seek -10 \n");
}
//暂停和继续
void music::on_stop_or_continue_clicked()
{
    if(flag == 0)
    {
        m_t->stop();
        music_pl->write("pause \n");
        flag++;
        ui->stop_or_continue->setText("PLAY");
    }
    else if(flag == 1)
    {
        m_t->start(1000);
        music_pl->write("pause \n");
        flag--;
        ui->stop_or_continue->setText("STOP");
    }
}

