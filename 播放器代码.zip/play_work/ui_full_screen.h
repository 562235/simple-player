/********************************************************************************
** Form generated from reading UI file 'full_screen.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FULL_SCREEN_H
#define UI_FULL_SCREEN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_full_screen
{
public:
    QWidget *centralwidget;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *full_screen)
    {
        if (full_screen->objectName().isEmpty())
            full_screen->setObjectName(QStringLiteral("full_screen"));
        full_screen->resize(800, 480);
        centralwidget = new QWidget(full_screen);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        full_screen->setCentralWidget(centralwidget);
        menubar = new QMenuBar(full_screen);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 28));
        full_screen->setMenuBar(menubar);
        statusbar = new QStatusBar(full_screen);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        full_screen->setStatusBar(statusbar);

        retranslateUi(full_screen);

        QMetaObject::connectSlotsByName(full_screen);
    } // setupUi

    void retranslateUi(QMainWindow *full_screen)
    {
        full_screen->setWindowTitle(QApplication::translate("full_screen", "MainWindow", 0));
    } // retranslateUi

};

namespace Ui {
    class full_screen: public Ui_full_screen {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FULL_SCREEN_H
