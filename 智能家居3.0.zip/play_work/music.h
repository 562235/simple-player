﻿#ifndef MUSIC_H
#define MUSIC_H

#include <QMainWindow>
#include <qdebug.h>
#include <QFile>
#include <QTextStream>
#include <QListWidgetItem>
#include <QListWidget>
#include <QFileDialog>
#include <QPixmap>
#include <QMessageBox>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
//进程类
#include <QProcess>
//目录类和文件类
#include <QDir>
#include <QFile>
//事件类
#include <QEvent>
#include <QMouseEvent>
//定时器类
#include <QTime>
#include <QTimer>

#define MUSIC_PATH "/mymusic/"
/*********手势***********/
#define Up          1
#define Down        2
#define Left        3
#define Right       4
#define Forward     5
/*********按键**********/
#define bt_up                   0
#define bt_hou                  1
#define bt_stop_or_continue     2
#define bt_qian                 3
#define bt_down                 4
#define music_list              5

namespace Ui {
class music;
}

class music : public QMainWindow
{
    Q_OBJECT

public:
    explicit music(QWidget *parent = nullptr);
    ~music();

    //寻找指定目录中的所有音乐文件
    void find_music_file(QString path, QStringList filters);
    //寻找指定目录中的所有歌词文件
    void find_music_lrc(QString path, QStringList filters);
    //寻找指定目录中的所有歌词对应的图片文件
    void find_music_backpic(QString path, QStringList filters);
    //从指定的歌词文件中获取正确的歌词数据
    void gain_lrc_data();
    //获取正确格式的时间
    void gain_time_now();
    //初始化
    void music_init();

    //按钮正常状态
    void button_common();
    //按钮高亮状态
    void button_highlight();
    //播放音乐
    void play_musci();
public slots:
    //每秒获取歌曲当前时间
    void music_plan();
    //读取播放器返回的数据
    void read_data();
    //手势识别函数
    void gesture();

signals:
    //退去音乐界面信号
    void music_quit(QString);

private slots:
    void on_up_clicked();

    void on_hou_clicked();

    void on_stop_or_continue_clicked();

    void on_qian_clicked();

    void on_down_clicked();

private:
    Ui::music *ui;
    //音乐进程
    QProcess *music_pl;
    //目录中所有音乐文件的路径列表
    QStringList music_files;
    //目录中所有歌词文件的路径列表
    QStringList music_lrc;
    //目录中的所有音乐对应的图片
    QStringList music_pic;
    //要播放的音乐路径
    QString play_path;
    //要显示的歌词路径
    QString lrc_path;
    //要显示的歌曲图片路径
    QString pic_path;
    //正在播放的音乐的歌词数据
    QStringList lrc_data;
    //定时器
    QTimer *m_t;
    //当前歌曲时间
    QString music_time;
    //真正需要的歌曲时间格式
    QString timenow;
    int flag = 0;
    //歌曲总长度
    float len;
    //滑动值
    int value;
    //音量
    int volume = 50;
    //鼠标坐标
    int y;
    //手势识别模块
    int gesture_fd;
    //手势识别定时器
    QTimer *gesture_timer;
    //选择器
    int selector = 0;
    //音乐播放选择器
    int music_selector = 0;
};

#endif // MUSIC_H
