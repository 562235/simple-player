﻿#ifndef FULL_SCREEN_H
#define FULL_SCREEN_H

#include <QMainWindow>
#include <qdebug.h>
#include <QProcess>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
//事件类
#include <QEvent>
#include <QMouseEvent>
//定时器
#include <QTimer>

namespace Ui {
class full_screen;
}

class full_screen : public QMainWindow
{
    Q_OBJECT

public:
    explicit full_screen(QWidget *parent = nullptr);
    ~full_screen();
    //退出全屏函数
     void full_quit();
    //获取上层窗体播放器的当前播放时间
    void full_play_time(QString &, int, float);

signals:
    void continue_play(int);

public slots:
    //显示播放器返回的数据
    void read_show();
    //每秒获取播放器当前时间
    void full_plan();
    //手势处理函数
    void gesture();
private:
    Ui::full_screen *ui;
    //播放时间
        float play_time;
        //播放器进程
        QProcess *full_pl;
        //播放器返回的数据
        QString read_msg;
        //获取视频进度的定时器
        QTimer *m_t;
        //手势识别模块描述符
        int gesture_fd;
        //手势识别定时器
        QTimer *gesture_timer;
};

#endif // FULL_SCREEN_H
