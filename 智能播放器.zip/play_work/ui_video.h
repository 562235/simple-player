/********************************************************************************
** Form generated from reading UI file 'video.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VIDEO_H
#define UI_VIDEO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_video
{
public:
    QWidget *centralwidget;
    QPushButton *pushButton;
    QSlider *horizontalSlider;
    QPushButton *stop_or_continue;
    QPushButton *down;
    QPushButton *hou;
    QFrame *line;
    QListWidget *listWidget;
    QLabel *background;
    QPushButton *up;
    QPushButton *qian;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *video)
    {
        if (video->objectName().isEmpty())
            video->setObjectName(QStringLiteral("video"));
        video->resize(800, 600);
        centralwidget = new QWidget(video);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(770, 170, 30, 40));
        pushButton->setStyleSheet(QLatin1String("border:2px groove gray;\n"
"border-radius:7px;\n"
"padding:2px 4px;"));
        horizontalSlider = new QSlider(centralwidget);
        horizontalSlider->setObjectName(QStringLiteral("horizontalSlider"));
        horizontalSlider->setGeometry(QRect(0, 400, 800, 20));
        horizontalSlider->setOrientation(Qt::Horizontal);
        stop_or_continue = new QPushButton(centralwidget);
        stop_or_continue->setObjectName(QStringLiteral("stop_or_continue"));
        stop_or_continue->setGeometry(QRect(360, 430, 80, 40));
        stop_or_continue->setStyleSheet(QLatin1String("border:2px groove gray;\n"
"border-radius:7px;\n"
"padding:2px 4px;color: rgb(255, 255, 0);"));
        down = new QPushButton(centralwidget);
        down->setObjectName(QStringLiteral("down"));
        down->setGeometry(QRect(590, 430, 50, 40));
        QFont font;
        font.setPointSize(15);
        down->setFont(font);
        down->setStyleSheet(QLatin1String("border:2px groove gray;\n"
"border-radius:7px;\n"
"padding:2px 4px;color: rgb(255, 255, 0);"));
        hou = new QPushButton(centralwidget);
        hou->setObjectName(QStringLiteral("hou"));
        hou->setGeometry(QRect(260, 430, 50, 40));
        hou->setStyleSheet(QLatin1String("border:2px groove gray;\n"
"border-radius:7px;\n"
"padding:2px 4px;color: rgb(255, 255, 0);"));
        line = new QFrame(centralwidget);
        line->setObjectName(QStringLiteral("line"));
        line->setGeometry(QRect(0, 420, 800, 5));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        listWidget = new QListWidget(centralwidget);
        listWidget->setObjectName(QStringLiteral("listWidget"));
        listWidget->setGeometry(QRect(680, 0, 120, 480));
        listWidget->setStyleSheet(QLatin1String("border:2px groove gray;\n"
"border-radius:7px;\n"
"padding:2px 4px;"));
        background = new QLabel(centralwidget);
        background->setObjectName(QStringLiteral("background"));
        background->setGeometry(QRect(0, 0, 800, 480));
        up = new QPushButton(centralwidget);
        up->setObjectName(QStringLiteral("up"));
        up->setGeometry(QRect(160, 430, 50, 40));
        up->setFont(font);
        up->setStyleSheet(QLatin1String("color: rgb(255, 255, 0);border:2px groove gray;\n"
"border-radius:7px;\n"
"padding:2px 4px;\n"
""));
        qian = new QPushButton(centralwidget);
        qian->setObjectName(QStringLiteral("qian"));
        qian->setGeometry(QRect(490, 430, 50, 40));
        qian->setStyleSheet(QLatin1String("border:2px groove gray;\n"
"border-radius:7px;\n"
"padding:2px 4px;color: rgb(255, 255, 0);"));
        video->setCentralWidget(centralwidget);
        background->raise();
        horizontalSlider->raise();
        stop_or_continue->raise();
        down->raise();
        hou->raise();
        line->raise();
        up->raise();
        qian->raise();
        pushButton->raise();
        listWidget->raise();
        menubar = new QMenuBar(video);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 28));
        video->setMenuBar(menubar);
        statusbar = new QStatusBar(video);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        video->setStatusBar(statusbar);

        retranslateUi(video);

        QMetaObject::connectSlotsByName(video);
    } // setupUi

    void retranslateUi(QMainWindow *video)
    {
        video->setWindowTitle(QApplication::translate("video", "MainWindow", 0));
        pushButton->setText(QApplication::translate("video", "<", 0));
        stop_or_continue->setText(QApplication::translate("video", "STOP", 0));
        down->setText(QApplication::translate("video", "-", 0));
        hou->setText(QApplication::translate("video", "<<", 0));
        background->setText(QString());
        up->setText(QApplication::translate("video", "+", 0));
        qian->setText(QApplication::translate("video", ">>", 0));
    } // retranslateUi

};

namespace Ui {
    class video: public Ui_video {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VIDEO_H
