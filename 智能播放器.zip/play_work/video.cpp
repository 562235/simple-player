﻿#include "video.h"
#include "ui_video.h"



video::video(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::video)
{
    ui->setupUi(this);
    //视频界面初始化
    init_video();
}

video::~video()
{
    delete [] video_pl;
    delete [] m_t;
    delete [] gesture_timer;
    delete ui;
}

/*************************
 *函数名：button_common
 *功能：视频界面的初始化
 */
void video::init_video()
{

    QPixmap background("/myvideo/video_background.jpg");    //设置背景图片
    background.scaled(this->width(), this->height());       //设置图片大小
    ui->background->setPixmap(background);                  //显示图片

    /***********视频界面的初始化**************/

    /****已进入到当前视频界面，应该从当前目录中获取所有的视频文件，显示到listWidget******/
    find_video_file("video_path", QStringList() << "*.avi");
    for(int i=0; i<video_files.size(); i++)
    {
        //tmp 视频名及后缀
        QString tmp = video_files.at(i);
        tmp.remove(0, tmp.lastIndexOf("/")+1);
        //path_tmp 小图标获取路径
        /*QString path_tmp = tmp;
        path_tmp =  path_tmp.remove(".avi") + ".jpg";
        path_tmp = "/myvideo/" + path_tmp;
        QIcon ic(path_tmp);

        QListWidgetItem *it  = new QListWidgetItem(ic, tmp);*/
        ui->listWidget->addItem(tmp);
    }

    video_pl = new QProcess(this);                                  //播放器进程
    connect(video_pl, SIGNAL(readyRead()), this, SLOT(read_show()));//关联mplay播放器的可读信号

    /***************手势识别模块****************/
    gesture_fd = open("/dev/IIC_drv", O_RDWR);
    if(gesture_fd >= 0)
    {
        qDebug() << " video gesture open succes" << endl;
    }
    gesture_timer = new QTimer(this);       //关联手势识别定时器
    connect(gesture_timer, SIGNAL(timeout()), this, SLOT(gesture()));
    gesture_timer->start(100);              //打开定时器，监控手势模块

    /************设置进度条的属性*********************/
    ui->horizontalSlider->setMaximum(100);
    ui->horizontalSlider->setValue(0);
    ui->listWidget->hide();
    button_highlight();                     //一进来up键应该高亮
}

/*************************
 *函数名：button_common
 *功能：按键正常状态
 */
void video::button_common()
{
    if(selector == bt_up)
    {
        ui->up->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 0);border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));//音量+正常
    }
    else if(selector == bt_hou)
    {
        ui->hou->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 0);border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));//快退正常
    }
    else if(selector == bt_stop_or_continue)
    {
        ui->stop_or_continue->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 0);border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));//暂停正常
    }
    else if(selector == bt_qian)
    {
        ui->qian->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 0);border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));//快进正常
    }
    else if(selector == bt_down)
    {
        ui->down->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 0);border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));//音量-正常
    }
}

/*************************
 *函数名：button_highlight
 *功能：按键高亮状态
 */
void video::button_highlight()
{
    if(selector == bt_up)
    {
        ui->up->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                     "padding:2px 4px;"));//音量+高亮
    }
    else if(selector == bt_hou)
    {
        ui->hou->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                 "padding:2px 4px;"));//快退高亮
    }
    else if(selector == bt_stop_or_continue)
    {
        ui->stop_or_continue->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                              "padding:2px 4px;"));//暂停高亮
    }
    else if(selector == bt_qian)
    {
        ui->qian->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                  "padding:2px 4px;"));//快进高亮
    }
    else if(selector == bt_down)
    {
        ui->down->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                  "padding:2px 4px;"));//音量-高亮
    }
}

/*************************
 *函数名：gesture
 *功能：处理手势传感器返回的数据
 */
void video::gesture()
{
    char data = 0;
    read(gesture_fd, &data, 1);             //获取手势识别模块返回的数据
    if(data>=1 && data<=9)                  //判断当前是什么手势
    {
        qDebug()  << "video_data:" << (int)data << endl;
        switch(data)
        {
            /***********手势向上时，执行对应的点击函数***********/
            case Up:
            if(selector ==      bt_up)
                on_up_clicked();                        //音量+
            else if(selector == bt_hou)
               on_hou_clicked();                        //快退10s
            else if(selector == bt_stop_or_continue)
                on_stop_or_continue_clicked();          //暂停/继续
            else if(selector == bt_qian)
                on_qian_clicked();                      //快进10s
            else if(selector == bt_down)
                on_down_clicked();                      //音量-
            else if(selector == video_list)             //切换选中的视频
            {
                if(video_selector==0)                   //如果选中项等于第一项，回到最后
                {
                    video_selector = video_files.size()-1;
                    ui->listWidget->setCurrentRow(video_selector);  //列表中的视频名称高亮
                    break;
                }
                video_selector--;
                ui->listWidget->setCurrentRow(video_selector);      //列表中的视频名称高亮
            }
            break;
            /***********手势向下***********/
            case Down:
            if(selector==video_list)                                //如果是选中了视频列表，则是上下切换选项
            {
                if(video_selector==video_files.size()-1)            //如果选中项等于视频总数时，回到第一项
                {
                    video_selector = 0;
                    ui->listWidget->setCurrentRow(video_selector);  //列表中的视频名称高亮
                    break;
                }
                video_selector++;
                ui->listWidget->setCurrentRow(video_selector);      //列表中的视频名称高亮
                break;
            }
            /***如果不是选中了视频列表，向下是退出本界面,如果进程正在运行,结束播放器后再退出****/
            if(video_pl->state() == QProcess::Running)
            {

                qDebug() << "Running" << endl;
                video_pl->write("quit \n");         //结束播放器
                this->parentWidget()->show();       //父窗体展示
                emit(video_quit("video"));          //发送信号，开启主界面手势处理函数
                gesture_timer->stop();              //本窗体手势定时器停止
                this->close();                      //关闭本窗体
            }
            /*****************如果进程没有运行,直接退出*************************/
            else if(video_pl->state() == QProcess::NotRunning)
            {
                qDebug() << "NotRunning" << endl;
                this->parentWidget()->show();       //父窗体展示，发送信号
                emit(video_quit("video"));          //发送信号，开启主界面手势处理函数
                gesture_timer->stop();              //本窗体手势定时器停止
                this->close();                      //关闭本窗体
            }
            break;
            /****************手势向左******************/
            case Left:
            button_common();            //原先的按钮恢复正常
            selector--;
            if(selector < 0)
                selector = video_list;
            if(selector == video_list)
            {
                ui->listWidget->show();
                ui->listWidget->setCurrentRow(video_selector);//列表中的视频名称高亮
            }
            else
                ui->listWidget->hide();
            button_highlight();         //指定的按钮高亮
            break;
            /***********手势向右***********/
            case Right:
            button_common();            //原先的按钮恢复正常
            selector++;
            if(selector > video_list)
                selector = 0;
            if(selector == video_list)//如果选中视频列表则显示出来
            {
                ui->listWidget->show();
                ui->listWidget->setCurrentRow(video_selector);//列表中的视频名称高亮
            }
            else
                ui->listWidget->hide();
            button_highlight();         //指定的按钮高亮
            break;
            /***********手势向前，播放选中的音乐***********/
            case Forward:
            play_video();               //播放选中的音乐
            ui->listWidget->hide();
            break;
            /****************手势晃动*******************/
            case Wave:
            full_screen_fun();          //全屏播放
            break;
            default:break;
        }

    }
}

/*************************
 *函数名：full_screen_fun
 *功能：切换成全屏
 */
void video::full_screen_fun ()
{
    m_t->stop();                                    //停止获取视频进度定时器
    gesture_timer->stop();                          //停止手势定时器
    video_pl->kill();                               //暂停当前播放器
    video_pl->waitForFinished();
    full_screen *full_win = new full_screen(this);  //在新窗体中全屏播放
    full_win->show();                               //传给子窗体 播放路径和时间
    full_win->full_play_time(play_path, ui->horizontalSlider->value(), len);
    this->hide();                                   //隐藏本窗体
}

/*************************
 *函数名：find_video_file
 *功能：遍历目录 找到所有的视频文件
 */
void video::find_video_file(QString path, QStringList filters)
{
    QDir dir(path);
    //搜索当前目录符合条件的文件
    foreach (QString file, dir.entryList(filters, QDir::Files))
        video_files += path + '/' + file;

    //搜索当前目录的子目录符合条件的文件
    foreach (QString subdir, dir.entryList(QDir::AllDirs | QDir::NoDotAndDotDot))
    {
        find_video_file(path + '/' + subdir, filters);
    }
}

/*************************
 *函数名：read_show
 *功能：读取播放器返回的数据
 */
void video::read_show()
{
    QString tmp = video_pl->readAll();
    read_msg = tmp;
    /****************如果是视频总长度,则保存len**********************/
    if(tmp.indexOf("LENGTH") >= 0)
    {
        len = tmp.remove(0, tmp.lastIndexOf("=")+1).remove("\n").toFloat();
    }
    /********************如果是当前时间，则保存read_msg******************/
    else if(read_msg.indexOf("TIME_POSITION") >= 0)
    {
        read_msg.remove(0, read_msg.lastIndexOf("=")+1).remove("\n");
    }
    int num = (int)(read_msg.toFloat()*100/len);  //将时间转换成进度条进度
    ui->horizontalSlider->setValue(num);
    qDebug() << "video:" << tmp << endl;
}

/*************************
 *函数名：contiue_play
 *功能：全屏后继续播放
 */
void video::contiue_play(int time)
{
    ui->horizontalSlider->show();           //更新进度条
    QString start_tmp = QString("mplayer -slave -quiet -zoom -x 800 -y 350 %1").arg(play_path);
    video_pl->start(start_tmp);             //播放视频
    m_t->start(1000);                       //打开定时器，继续获取视频进度
    gesture_timer->start(100);              //打开手势识别定时器
    QString tmp = QString("seek %1 1 \n").arg(time);
    video_pl->write(tmp.toUtf8().data());   //更新视频进度，对接全屏时播放进度
}

/************************
 *函数名：video_plan
 *功能：每秒获取视频的进度
 */
void video::video_plan()
{
    //打印出在文件的当前位置用秒表示，采用浮点数
    video_pl->write("get_time_pos \n");
}

/************************
 *函数名：on_stop_or_continue_clicked
 *功能：暂停和继续
 */
void video::on_stop_or_continue_clicked()
{
    //暂停
    if(flag == 0)
    {
        m_t->stop();
        video_pl->write("pause \n");
        flag++;
        ui->stop_or_continue->setText("PLAY");
    }
    //播放
    else if(flag == 1)
    {
        m_t->start(1000);
        video_pl->write("pause \n");
        flag--;
        ui->stop_or_continue->setText("STOP");
    }

}

/*************************
 *函数名：play_video
 *功能：播放函数，开启定时器，每秒获取视频进度
 */
void video::play_video()
{
    play_path = ui->listWidget->item(video_selector)->text();
    play_path = "/myvideo/" + play_path;
    /***********如果进程没有运行,直接开始运行******************/
    if(video_pl->state() == QProcess::NotRunning)
    {
        QString start_tmp = QString("mplayer -slave -quiet -zoom -x 800 -y 350 %1").arg(play_path);//打开mplay播放器
        video_pl->start(start_tmp);                             //开始播放视频
        video_pl->write("get_time_length  \n");                 //获取视频总长度
        /*******************定时器 每秒获取视频进度***************/
        m_t = new QTimer(this);
        connect(this->m_t, SIGNAL(timeout()), this, SLOT(video_plan()));
        this->m_t->start(1000);
    }
    /*******************如果进程正在运行*******************/
    else if(video_pl->state() == QProcess::Running)
    {
        m_t->stop();                                //暂停定时器
        video_pl->kill();                           //杀死进程
        video_pl->waitForFinished();                //回收资源
        QString start_tmp = QString("mplayer -slave -quiet -zoom -x 800 -y 350 %1").arg(play_path);//打开mplay播放器
        video_pl->start(start_tmp);
        video_pl->write("get_time_length  \n");     //获取视频总长度
        m_t->start(1000);
    }
}

/**********************
 *函数名：on_up_clicked
 *功能：音量+
 */
void video::on_up_clicked()
{
    if(volume == 100)
    {
        qDebug() << "温馨提示,音量以增大至100" << endl;
    }
    else
    {
        volume += 10;
        QString msg = QString("volume %1 1\n").arg(volume);
        video_pl->write(msg.toUtf8().data());
    }

}

/*********************
 *函数名：on_down_clicked
 *功能：音量-
 */
void video::on_down_clicked()
{
    if(volume == 0)
    {
        qDebug() << "温馨提示,音量以减小至0" << endl;
    }
    else
    {
        volume -= 10;
        QString msg = QString("volume %1 1\n").arg(volume);
        video_pl->write(msg.toUtf8().data());
    }
}

/***********************
 *函数名：on_hou_clicked
 *功能：快退 10s
 */
void video::on_hou_clicked()
{
    video_pl->write("seek -10 \n");
}

/***********************
 *函数名：on_qian_clicked
 *功能：快进 10s
 */
void video::on_qian_clicked()
{
    video_pl->write("seek +10 \n");
}

