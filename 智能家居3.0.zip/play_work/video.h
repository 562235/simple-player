﻿#ifndef VIDEO_H
#define VIDEO_H


#include <QMainWindow>
#include <QMainWindow>
#include <qdebug.h>
#include <QTime>
#include <QTimer>
#include <QIcon>
#include <QListWidget>
#include <QMessageBox>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <QProcess>
#include <QDir>
#include <QFile>
#include <QListWidgetItem>
#include <QEvent>
#include <QMouseEvent>
#include <QTimer>
#include <full_screen.h>

#define VIDEO_PATH "/myvideo/"
/*********手势***********/
#define Up          1
#define Down        2
#define Left        3
#define Right       4
#define Forward     5
#define Wave        9
/*********按键**********/
#define bt_up                   0
#define bt_hou                  1
#define bt_stop_or_continue     2
#define bt_qian                 3
#define bt_down                 4
#define video_list              5

namespace Ui {
class video;
}

class video : public QMainWindow
{
    Q_OBJECT

public:
    explicit video(QWidget *parent = nullptr);
    ~video();
    //全屏播放函数
    void full_screen_fun();
    //寻找指定目录中的所有jpg文件
    void find_video_file(QString path, QStringList filters);
    //初始化
    void init_video();
    //按钮正常状态
    void button_common();
    //按钮高亮状态
    void button_highlight();
    //视频播放函数
    void play_video();

signals:
    void video_quit(QString);

public slots:
    //读取并显示播放器返回的数据
    void read_show();

    //全屏后继续播放
    void contiue_play(int);

    //每秒发送获取视频进度命令
    void video_plan();

    //手势处理函数
    void gesture();
private slots:

    void on_stop_or_continue_clicked();

    void on_up_clicked();

    void on_down_clicked();

    void on_hou_clicked();

    void on_qian_clicked();

private:
    Ui::video *ui;
    //视频进程
    QProcess *video_pl;
    //目录中所有视频文件的路径列表
    QStringList video_files;
    //要播放的视频路径
    QString play_path;
    //播放器返回的数据
    QString read_msg;
    float len;
    //定时器
    QTimer *m_t;

    int flag=0;
    //进度条滑动值
    int value;
    //音量
    int volume = 50;
    //鼠标坐标
    int y;
    //手势识别模块
    int gesture_fd;
    //手势识别定时器
    QTimer *gesture_timer;
    //控件选择器
    int selector = 0;
    //音乐播放选择器
    int video_selector = 0;
};

#endif // VIDEO_H
