﻿#include "monitoring.h"
#include "ui_monitoring.h"



monitoring::monitoring(QMainWindow *parent) :
    QMainWindow(parent),
    ui(new Ui::monitoring)
{
    ui->setupUi(this);
    //创建定时器，用来不断获取摄像头数据
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(show_camera()));

    //初始化摄像头设备
    linux_v4l2_yuyv_init("/dev/video7");
    //开启摄像头的捕捉画面功能
    linux_v4l2_start_yuyv_capturing();

    //开启定时器1 开启视频
    timer->start(1);
}
/**********
 * 函数名：show_camera
 * 功能：显示图像
 *
 */
void monitoring::show_camera()
{
    struct jpg_data jpg_buf;

    bzero(&jpg_buf,sizeof(jpg_buf));
    //获取一帧的数据
    linux_v4l2_get_yuyv_data(&jpg_buf);

    QPixmap pic;
    pic.loadFromData(jpg_buf.jpg_data, jpg_buf.jpg_size);
    //适应标签的大小
    pic.scaled(ui->label->width(), ui->label->height());

    ui->label->setPixmap(pic);
}

monitoring::~monitoring()
{
    delete [] timer;
    delete ui;
}
