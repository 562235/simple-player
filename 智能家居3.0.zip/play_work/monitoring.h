﻿#ifndef MONITORING_H
#define MONITORING_H

#include <QMainWindow>
#include <QTimer>
extern "C"
{
    #include "yuyv.h"
}
namespace Ui {
class monitoring;
}

class monitoring : public QMainWindow
{
    Q_OBJECT

public:
    explicit monitoring(QMainWindow *parent = nullptr);

    ~monitoring();
public slots:
    //显示摄像头数据
    void show_camera();
private:
    Ui::monitoring *ui;
    //处理摄像头数据
    struct jpg_data jpg_buf;
    //定时器
    QTimer *timer;
};

#endif // MONITORING_H
