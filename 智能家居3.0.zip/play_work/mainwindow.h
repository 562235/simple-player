﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPixmap>
#include <QPainter>
#include <QFileDialog>
#include <QDebug>
#include <QFile>
#include <QTimer>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

#include "video.h"
#include "music.h"
#include "monitoring.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    //按钮正常状态
    void button_common();
    //按钮高亮状态
    void button_highlight();

public slots:
    void gesture();//手势识别函数
    void gesture_restart(QString);//手势定时器重启

private slots:
    void on_beijing_clicked();

    void on_music_clicked();

    void on_video_clicked();

    void on_moning_clicked();

private:
    Ui::MainWindow *ui;
    //PXIMAP列表 存放主界面显示的图片
    QList<QPixmap> pic_list;
    //画面切换 标志数
    int pic_tmp = 0;
    //音乐界面子窗体
    music *music_win;
    //视频界面子窗体
    video *video_win;
    //监控界面子窗口
    monitoring * monitoring_win;
    //监控界面显示标志
    int monitoring_flag = 0;
    //手势定时器
    QTimer *gesture_time;
    //手势识别模块
    int gesture_fd;
    //选择器，用来选定不同的功能
    int selector = 0;
};
#endif // MAINWINDOW_H
