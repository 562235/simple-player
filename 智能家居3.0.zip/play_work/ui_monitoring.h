/********************************************************************************
** Form generated from reading UI file 'monitoring.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MONITORING_H
#define UI_MONITORING_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_monitoring
{
public:
    QLabel *label;

    void setupUi(QWidget *monitoring)
    {
        if (monitoring->objectName().isEmpty())
            monitoring->setObjectName(QStringLiteral("monitoring"));
        monitoring->resize(400, 300);
        label = new QLabel(monitoring);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(0, 0, 400, 300));

        retranslateUi(monitoring);

        QMetaObject::connectSlotsByName(monitoring);
    } // setupUi

    void retranslateUi(QWidget *monitoring)
    {
        monitoring->setWindowTitle(QApplication::translate("monitoring", "Form", 0));
        label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class monitoring: public Ui_monitoring {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MONITORING_H
