﻿#include "full_screen.h"
#include "ui_full_screen.h"

full_screen::full_screen(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::full_screen)
{
    ui->setupUi(this);
    full_pl = new QProcess(this);                                       //播放器进程
    connect(full_pl, SIGNAL(readyRead()), this, SLOT(read_show()));     //关联mplay播放器的可读信号

    /********************打开手势识别模块驱动***********************/
    gesture_fd = open("/dev/IIC_drv", O_RDWR);
    if(gesture_fd < 0)
    {
        qDebug() << "full gesture open succeed" << endl;
    }
    gesture_timer = new QTimer(this);                                   //创建手势识别定时器
    connect(gesture_timer, SIGNAL(timeout()), this, SLOT(gesture()));   //关联手势识别定时器
    gesture_timer->start(100);                                          //打开定时器，监控手势模块
}

full_screen::~full_screen()
{
    delete [] full_pl;
    delete [] m_t;
    delete [] gesture_timer;
    delete ui;
}
/*************************
 *函数名：gesture
 *功能：手势处理函数
 */
void full_screen::gesture()
{
    char data = 0;
    read(gesture_fd, &data, 1);     //获取手势识别模块返回的数据
    if(data>=1 && data<=9)          //判断当前是什么手势
    {
        qDebug()  << "full_data:" << (int)data << endl;
        switch(data)
        {
        /*******手势向下 退出全屏********/
            case 2:
            full_quit();            //退出全屏函数
            break;
            default:break;
        }
    }
}

/*************************
 *函数名：full_quit
 *功能：退出全屏函数
 */
void full_screen::full_quit()
{

    m_t->stop();                        //停止视频进度定时器
    gesture_timer->stop();              //停止手势定时器

    QString tmp_data = read_msg;        //获取当前播放的进度
    tmp_data.remove(0, tmp_data.lastIndexOf("=")+1).remove("\n");
    float tmp_num = tmp_data.toFloat();

    int video_progress   = (int)(tmp_num*100/play_time);//将进度转化成百分制
    qDebug() << "tmp_data:" << tmp_data << endl;

    full_pl->kill();                    //停止当前播放器和定时器
    full_pl->waitForFinished();

    this->parentWidget()->show();       //关闭全屏后父窗体继续播放信息
    connect(this, SIGNAL(continue_play(int)), this->parent(), SLOT(contiue_play(int)));
    emit continue_play(video_progress);
    this->close();
}

/*************************
 *函数名：full_play_time
 *功能：获取上层窗体播放器的当前播放时间
 */
void full_screen::full_play_time(QString & name, int time_now, float time)
{
    play_time = time;
    QString start_tmp = QString("mplayer -slave -quiet -zoom -x 800 -y 480 %1").arg(name);//播放父窗体正在播放的视频
    full_pl->start(start_tmp);
    start_tmp = QString("seek %1 1\n").arg(time_now);       //将视频的进度接在父窗体后面
    full_pl->write(start_tmp.toUtf8().data());              //发送命令
    /************开启定时器，每秒获取视频进度************/
    m_t = new QTimer(this);
    connect(this->m_t, SIGNAL(timeout()), this, SLOT(full_plan()));
    this->m_t->start(1000);
}

/*************************
 *函数名：read_show
 *功能：读取播放器返回的数据
 */
void full_screen::read_show()
{
    read_msg.clear();
    QString tmp = full_pl->readAll();
    read_msg = tmp;
    //qDebug() << tmp << endl;
}

/*************************
 *函数名：full_plan
 *功能：发送获取当前时间命令
 */
void full_screen::full_plan()
{
    full_pl->write("get_time_pos \n");
}
