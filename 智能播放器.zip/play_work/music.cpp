﻿#include "music.h"
#include "ui_music.h"

music::music(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::music)
{
    ui->setupUi(this);
    //初始化音乐界面
    music_init();
}

music::~music()
{
    delete [] music_pl;
    delete [] m_t;
    delete [] gesture_timer;
    delete ui;
}
/*****************************
 *函数名：music_init
 *功能：初始化音乐界面
 */
void music::music_init()
{
    QPixmap background("/mymusic/music_bagrod.jpg");    //设置背景图片
    background.scaled(this->width(), this->height());   //设置图片大小
    ui->background->setPixmap(background);              //显示图片

    /**已进入到当前音乐界面，应该从/IOT目录中获取所有的音乐文件，显示到listWidget(C:/Users/62307/Videos/Captures)**/
    find_music_file(music_path, QStringList() << "*.mp3");
    for(int i=0; i<music_files.size(); i++)
    {
        QString tmp = music_files.at(i);
        tmp.remove(0, tmp.lastIndexOf("/")+1);
        ui->listWidget->addItem(tmp);
    }

    find_music_lrc(music_path, QStringList() << "*.lrc");           //已进入到当前音乐界面，应该从/IOT目录中获取所有的歌词文件
    find_music_backpic(music_path, QStringList() << "*.jpg");       //已进入到当前音乐界面，应该从/IOT目录中获取所有的图片文件

    music_pl = new QProcess(this);                                  //播放器进程
    connect(music_pl, SIGNAL(readyRead()), this, SLOT(read_data()));//关联mplay播放器的可读信号

    /****************手势识别模块************************/
    gesture_fd = open("/dev/IIC_drv", O_RDWR);
    if(gesture_fd >= 0)
    {
        qDebug() << "music gesture open succes" << endl;
    }
    gesture_timer = new QTimer(this);                                 //手势识别定时器
    connect(gesture_timer, SIGNAL(timeout()), this, SLOT(gesture())); //关联手势识别定时器
    gesture_timer->start(100);                                        //打开定时器，监控手势模块

    /****************设置进度条的属性****************/
    ui->horizontalSlider->setMaximum(100);
    ui->horizontalSlider->setValue(0);
    ui->listWidget->hide();

    button_highlight();                                               //一进来up键应该高亮
}

/*****************************
 *函数名：gesture
 *功能：处理手势传感器返回的数据
 */
void music::gesture()
{
    char data = 0;
    read(gesture_fd, &data, 1);                 //获取手势识别模块返回的数据
    if(data>=1 && data<=9)                      //判断当前是什么手势
    {
        qDebug()  << "music_data:" << (int)data << endl;
        switch(data)
        {
            /*************手势向上时，执行对应的点击函数****************/
            case Up:
            if(selector==bt_up)
                on_up_clicked();                //音量+
            else if(selector==bt_hou)
               on_hou_clicked();                //快退10s
            else if(selector==bt_stop_or_continue)
                on_stop_or_continue_clicked();  //暂停/继续
            else if(selector==bt_qian)
                on_qian_clicked();              //快进10s
            else if(selector==bt_down)
                on_down_clicked();              //音量-
            else if(selector==music_list)       //切换选中的音乐
            {
                if(music_selector==0)           //如果选中项等于第一项，回到最后
                {
                    music_selector = music_files.size()-1;
                    ui->listWidget->setCurrentRow(music_selector);  //列表中的音乐名称高亮
                    break;
                }
                music_selector--;
                ui->listWidget->setCurrentRow(music_selector);      //列表中的音乐名称高亮
            }
            break;
            /*********************手势向下********************/
            case Down:
            if(selector==music_list)            //如果是选中了音乐列表，则是上下切换选项
            {
                if(music_selector==music_files.size()-1)            //如果选中项等于音乐总数时，回到第一项
                {
                    music_selector = 0;
                    ui->listWidget->setCurrentRow(music_selector);  //列表中的音乐名称高亮
                    break;
                }
                music_selector++;
                ui->listWidget->setCurrentRow(music_selector);      //列表中的音乐名称高亮
                break;
            }

            if(music_pl->state() == QProcess::Running)      //如果不是选中了音乐列表，向下是退出本界面,如果进程正在运行,结束播放器后再退出
            {

                qDebug() << "Running" << endl;
                music_pl->write("quit \n");                         //结束播放器
                gesture_timer->stop();                              //停止手势定时器
                this->parentWidget()->show();                       //展示主界面
                emit(music_quit("music"));                          //发送信号，开启主界面手势定时器
                this->close();                                      //关闭本窗体
            }

            else if(music_pl->state() == QProcess::NotRunning)//如果进程没有运行,直接退出
            {
                qDebug() << "NotRunning" << endl;
                this->parentWidget()->show();                       //父窗体展示
                emit(music_quit("music"));                          //发送信号，开启主界面手势定时器
                gesture_timer->stop();                              //本窗体手势识别定时器停止工作
                this->close();                                      //关闭本窗体
            }
            break;
            /*********************手势向左**********************/
            case Left:
            button_common();                            //原先的按钮恢复正常
            selector--;
            if(selector < 0)
                selector = music_list;
            if(selector == music_list)
            {
                ui->listWidget->show();
                ui->listWidget->setCurrentRow(music_selector);//列表中的音乐名称高亮
            }
            else
                ui->listWidget->hide();
            button_highlight();                         //指定的按钮高亮
            break;
            /**************************手势向右***********************/
            case Right:
            button_common();                            //原先的按钮恢复正常
            selector++;
            if(selector > music_list)
                selector = 0;
            if(selector == music_list)                  //如果选中音乐列表则显示出来
            {
                ui->listWidget->show();
                ui->listWidget->setCurrentRow(music_selector);//列表中的音乐名称高亮
            }
            else
                ui->listWidget->hide();
            button_highlight();                         //指定的按钮高亮
            break;
            /********************手势向前，播放选中的音乐********************/
            case Forward:
            play_musci();                               //播放选中的音乐
            ui->listWidget->hide();
            break;
            default:break;
        }

    }
}

/*****************************
 *button_common
 *功能：按钮正常状态
 */
void music::button_common()
{
    if(selector == bt_up)
    {
        ui->up->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 0);border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));//音量+正常
    }
    else if(selector == bt_hou)
    {
        ui->hou->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 0);border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));//快退正常
    }
    else if(selector == bt_stop_or_continue)
    {
        ui->stop_or_continue->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 0);border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));//暂停正常
    }
    else if(selector == bt_qian)
    {
        ui->qian->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 0);border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));//快进正常
    }
    else if(selector == bt_down)
    {
        ui->down->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 0);border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));//音量-正常
    }
}

/*****************************
 *button_highlight
 *功能：按钮高亮状态
 */
void music::button_highlight()
{
    if(selector == bt_up)
    {
        ui->up->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                     "padding:2px 4px;"));//音量+高亮
    }
    else if(selector == bt_hou)
    {
        ui->hou->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                 "padding:2px 4px;"));//快退高亮
    }
    else if(selector == bt_stop_or_continue)
    {
        ui->stop_or_continue->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                              "padding:2px 4px;"));//暂停高亮
    }
    else if(selector == bt_qian)
    {
        ui->qian->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                  "padding:2px 4px;"));//快进高亮
    }
    else if(selector == bt_down)
    {
        ui->down->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                  "padding:2px 4px;"));//音量-高亮
    }
}

/*****************************
 *play_musci
 *功能：播放选中的音乐
 */
void music::play_musci()
{
    /******处理选中的音乐，得到其路径******************/
    QString tmp_path = ui->listWidget->item(music_selector)->text();
    play_path = music_path + tmp_path;
    tmp_path = tmp_path.remove(".mp3");
    /******遍历歌词列表music_lrc，找到对应的歌词文件*****/
    for(int i=0; i<music_lrc.size(); i++)
    {
        if(music_lrc.at(i).indexOf(tmp_path)>=0)
        {
            lrc_path = music_lrc.at(i);
            break;
        }
    }
    /******遍历歌曲图片列表music_pic，找到对应的歌曲图片*****/
    for(int i=0; i<music_pic.size(); i++)
    {
        //找到以后，显示图片
        if(music_pic.at(i).indexOf(tmp_path)>=0)
        {
            pic_path = music_pic.at(i); 
            QPixmap background(pic_path);                       //设置背景图片
            background.scaled(this->width(), this->height());   //设置图片大小
            ui->background->setPixmap(background);              //显示图片
            break;
        }
    }
    /**************判断原来的音乐是否在播放***************/
    if(music_pl->state() == QProcess::NotRunning)
    {
        QString start_tmp = QString("mplayer -slave -quiet -zoom -x 800 -y 370 %1").arg(play_path);//创建一个进程，打开mplay播放器
        music_pl->start(start_tmp);                     //开始播放
        gain_lrc_data();                                //获取歌词数据到 lrc_data中了
        music_pl->write("get_time_length  \n");         //获取视频总长度

        m_t = new QTimer(this);                         //开启定时器，准备定位歌词
        connect(this->m_t, SIGNAL(timeout()), this, SLOT(music_plan()));
        this->m_t->start(1000);
    }
    /**************判断原来的音乐是否在播放***************/
    else if(music_pl->state() == QProcess::Running)
    {        
        m_t->stop();                                    //暂停定时器
        music_pl->kill();                               //杀死进程
        music_pl->waitForFinished();                    //回收资源
        QString start_tmp = QString("mplayer -slave -quiet -zoom -x 800 -y 370 %1").arg(play_path);//打开mplay播放器
        music_pl->start(start_tmp);                     //开始播放音乐
        gain_lrc_data();                                //获取歌词数据到 lrc_data中
        music_pl->write("get_time_length  \n");         //获取视频总长度
        m_t->start(1000);

    }

}

/*****************************
 *函数名：find_music_file
 *功能：遍历目录 找到所有的音乐文件
 */
void music::find_music_file(QString path, QStringList filters)
{
    QDir dir(path);
    //搜索当前目录符合条件的文件
    foreach (QString file, dir.entryList(filters, QDir::Files))
        music_files += path + '/' + file;

    //搜索当前目录的子目录符合条件的文件
    foreach (QString subdir, dir.entryList(QDir::AllDirs | QDir::NoDotAndDotDot))
    {
        find_music_file(path + '/' + subdir, filters);
    }

}

/*****************************
 *函数名：find_music_lrc
 *功能：遍历目录 找到所有的歌词文件
 */
void music::find_music_lrc(QString path, QStringList filters)
{
    QDir dir(path);
    //搜索当前目录符合条件的文件
    foreach (QString file, dir.entryList(filters, QDir::Files))
        music_lrc += path + '/' + file;

    //搜索当前目录的子目录符合条件的文件
    foreach (QString subdir, dir.entryList(QDir::AllDirs | QDir::NoDotAndDotDot))
    {
        find_music_file(path + '/' + subdir, filters);
    }

}

/*****************************
 *函数名：find_music_backpic
 *功能：寻找指定目录中的所有歌词对应的图片文件
 */
void music::find_music_backpic(QString path, QStringList filters)
{
    QDir dir(path);
    //搜索当前目录符合条件的文件
    foreach (QString file, dir.entryList(filters, QDir::Files))
        music_pic += path + '/' + file;

    //搜索当前目录的子目录符合条件的文件
    foreach (QString subdir, dir.entryList(QDir::AllDirs | QDir::NoDotAndDotDot))
    {
        find_music_file(path + '/' + subdir, filters);
    }
}

/*****************************
 *函数名：gain_lrc_data
 *功能：到指定的歌词文件中，获取正确的歌词数据
 */
void music::gain_lrc_data()
{
    //打开文件夹读取文件中的内容
    QFile file(lrc_path);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    while (!file.atEnd())
    {
        QString line = file.readLine();
       //形成歌词列表
       lrc_data.append(line);
    }

}

/*****************************
 *函数名：gain_time_now
 *功能：将music_time转换成需要的格式 [00:00
 */
void music::gain_time_now()
{
    int fen = 0;            //分
    int miao = 0;           //秒
    for(;music_time.toDouble()>=60;)
    {
        fen++;
        music_time = QString::number(music_time.toDouble()-60);
    }
    miao=music_time.toFloat();
    if(fen<=10 && miao<10)
    {
        timenow = QString("[0%1:0%2").arg(fen).arg(miao);
    }
    else if (fen<10 && miao>=10)
    {
        timenow = QString("[0%1:%2").arg(fen).arg(miao);
    }
}

/*****************************
 *函数名：music_plan
 *功能：每秒发送获取歌曲当前时间和实时显示歌词
 */
void music::music_plan()
{   
    music_pl->write("get_time_pos \n");     //获取歌曲当前时间
    gain_time_now();                        //得到真正需要的时间timenow
    /******************显示歌词******************/
    for(int i=0; i<lrc_data.size(); i++)
    {
        /************删除掉时间后再显示，因为歌词前面有时间前缀************/
        if(lrc_data.at(i).indexOf(timenow)>=0)
        {
            QString ge_tmp = lrc_data.at(i);
            ge_tmp.remove(0, ge_tmp.lastIndexOf("]")+1);
            ui->gechi->setText(ge_tmp);
            break;
        }
    }
}
/*****************************
 *函数名：read_data
 *功能：读取播放器返回的数据
 */
void music::read_data()
{
    QString tmp = music_pl->readAll();
    /***********如果读到的是总时间******************/
    if(tmp.indexOf("LENGTH") >= 0)
    {
        len = tmp.remove(0, tmp.lastIndexOf("=")+1).remove("\n").toFloat();
    }
    /******************如果读到的是当前时间**********************/
    if(tmp.indexOf("TIME_POSITION")>=0)
    {
        music_time =  tmp.remove(0, tmp.lastIndexOf("=")+1).remove("\n");
    }
    int data = (int)(music_time.toFloat()*100/len);     //将时间转换成进度条
    ui->horizontalSlider->setValue(data);
    qDebug() << tmp << endl;                            //打印读到的数据
}
/*****************************
 *函数名：on_up_clicked
 *功能：音量+
 */
void music::on_up_clicked()
{
    if(volume == 100)
    {
        qDebug() << "温馨提示,音量以增大至100" << endl;
    }
    else
    {
        volume += 10;
        QString msg = QString("volume %1 1\n").arg(volume);
        music_pl->write(msg.toUtf8().data());
    }
}
/*****************************
 *函数名：on_down_clicked
 *功能：音量-
 */
void music::on_down_clicked()
{
    if(volume == 0)
    {
         qDebug() << "温馨提示,音量以减小至0" << endl;
    }
    else
    {
        volume -= 10;
        QString msg = QString("volume %1 1\n").arg(volume);
        music_pl->write(msg.toUtf8().data());
    }
}
/*****************************
 *函数名：on_qian_clicked
 *功能：快进 10s
 */
void music::on_qian_clicked()
{
    music_pl->write("seek 10 \n");
}

/*****************************
 *函数名：on_hou_clicked
 *功能：快退 10s
 */
void music::on_hou_clicked()
{
    music_pl->write("seek -10 \n");
}
/*****************************
 *函数名：on_stop_or_continue_clicked
 *功能：暂停和继续
 */
void music::on_stop_or_continue_clicked()
{
    if(flag == 0)
    {
        m_t->stop();
        music_pl->write("pause \n");
        flag++;
        ui->stop_or_continue->setText("PLAY");
    }
    else if(flag == 1)
    {
        m_t->start(1000);
        music_pl->write("pause \n");
        flag--;
        ui->stop_or_continue->setText("STOP");
    }
}

