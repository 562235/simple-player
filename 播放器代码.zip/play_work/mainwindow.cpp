﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    pic_list.clear();
    //默认的添加3张背景图片
    QPixmap pic("/myphoto/jiemian1.jpg");
    pic_list.append(pic);
    pic = QPixmap("/myphoto/jiemian2.jpg");
    pic_list.append(pic);
    pic = QPixmap("/myphoto/jiemian3.jpg");
    pic_list.append(pic);
    //开始显示图片,先设置图片大小适应屏幕
    pic_list.at(pic_tmp).scaled(this->width(), this->height());
    ui->background->setPixmap(pic_list.at(pic_tmp++));

    //手势识别模块
    gesture_fd = open("/dev/IIC_drv", O_RDWR);
    if(gesture_fd >= 0)
    {
        qDebug() << "open succes" << endl;
    }
    //开启手势定时器
    gesture_time = new QTimer(this);
    connect(gesture_time, SIGNAL(timeout()), this, SLOT(gesture()));
    gesture_time->start(100);

}

MainWindow::~MainWindow()
{
    delete ui;
}
//按钮正常状态
void MainWindow::button_common()
{
    if(selector == 0)
    {
        ui->beijing->setStyleSheet(QString::fromUtf8("border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));
    }
    else if(selector == 1)
    {
        ui->music->setStyleSheet(QString::fromUtf8("border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));
    }
    else
    {
        ui->video->setStyleSheet(QString::fromUtf8("border:2px groove gray;\n""border-radius:7px;\n""padding:2px 4px;"));
    }
}
//按钮高亮状态
void MainWindow::button_highlight()
{
    if(selector == 0)
    {
        ui->beijing->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                     "padding:2px 4px;"));
    }
    else if(selector == 1)
    {
        ui->music->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                     "padding:2px 4px;"));
    }
    else
    {
        ui->video->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n""border:2px groove gray;\n""border-radius:7px;\n"
                                                     "padding:2px 4px;"));
    }

}
//手势识别模块
void MainWindow::gesture()
{
    char data = 0;
    read(gesture_fd, &data, 1);//获取手势识别模块返回的数据
    if(data>=1 && data<=9)//判断当前是什么手势
    {
        qDebug()  << "mian_data:" << (int)data << endl;
        switch(data)
        {
            /****************手势向上时，执行对应的点击函数**************/
            case 1:
            if(selector==0)
                on_beijing_clicked();//切换背景
            else if(selector==1)
            {
                on_music_clicked();//进入音乐界面
            }
            else if(selector==2)
            {
                on_video_clicked();//进入视频界面
            }
            break;
            /***********************手势向左**********************/
            case 3:
            button_common();//原先的按钮恢复正常
            selector--;
            if(selector < 0)
                selector = 2;
            button_highlight();//指定的按钮高亮
            break;
            /*********************手势向右**********************/
            case 4:
            button_common();//原先的按钮恢复正常
            selector++;
            if(selector > 2)
                selector = 0;
            button_highlight();//指定的按钮高亮
            break;
            default:break;
        }

    }
}
//手势定时器重启函数
void MainWindow::gesture_restart(QString win_name)
{
    qDebug() << win_name +" quit" << endl;
    gesture_time->start(100);
}
//点击切换背景图片
void MainWindow::on_beijing_clicked()
{
    //开始显示图片,先设置图片大小适应屏幕
    pic_list.at(pic_tmp).scaled(this->width(), this->height());
    ui->background->setPixmap(pic_list.at(pic_tmp++));
    //如果循环到尾，则重新开始
    if(pic_tmp == pic_list.size())
        pic_tmp = 0;
}
//点击后，跳转到音乐界面
void MainWindow::on_music_clicked()
{
    //创建音乐窗口
    music_win = new music(this);
    gesture_time->stop();
    //关联手势重启信号
    connect(music_win, SIGNAL(music_quit(QString)), this, SLOT(gesture_restart(QString)));
    music_win->show();
    this->hide();
}
//点击后，跳转到视频界面
void MainWindow::on_video_clicked()
{
    //创建视频窗口
    video_win = new video(this);
    gesture_time->stop();
    //关联手势重启信号
    connect(video_win, SIGNAL(video_quit(QString)), this, SLOT(gesture_restart(QString)));
    video_win->show();
    this->hide();
}
