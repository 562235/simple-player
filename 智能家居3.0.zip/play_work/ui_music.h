/********************************************************************************
** Form generated from reading UI file 'music.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MUSIC_H
#define UI_MUSIC_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_music
{
public:
    QWidget *centralwidget;
    QPushButton *qian;
    QListWidget *listWidget;
    QPushButton *up;
    QPushButton *down;
    QPushButton *hou;
    QPushButton *stop_or_continue;
    QFrame *line;
    QSlider *horizontalSlider;
    QLabel *gechi;
    QLabel *background;
    QPushButton *pushButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *music)
    {
        if (music->objectName().isEmpty())
            music->setObjectName(QStringLiteral("music"));
        music->resize(800, 600);
        centralwidget = new QWidget(music);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        qian = new QPushButton(centralwidget);
        qian->setObjectName(QStringLiteral("qian"));
        qian->setGeometry(QRect(490, 430, 50, 40));
        qian->setStyleSheet(QLatin1String("border:2px groove gray;\n"
"border-radius:7px;\n"
"padding:2px 4px;color: rgb(255, 255, 0);"));
        listWidget = new QListWidget(centralwidget);
        listWidget->setObjectName(QStringLiteral("listWidget"));
        listWidget->setGeometry(QRect(680, 0, 120, 480));
        listWidget->setStyleSheet(QLatin1String("border:2px groove gray;\n"
"border-radius:7px;\n"
"padding:2px 4px;"));
        up = new QPushButton(centralwidget);
        up->setObjectName(QStringLiteral("up"));
        up->setGeometry(QRect(160, 430, 50, 40));
        QFont font;
        font.setPointSize(15);
        up->setFont(font);
        up->setStyleSheet(QLatin1String("color: rgb(255, 255, 0);border:2px groove gray;\n"
"border-radius:7px;\n"
"padding:2px 4px;\n"
""));
        down = new QPushButton(centralwidget);
        down->setObjectName(QStringLiteral("down"));
        down->setGeometry(QRect(590, 430, 50, 40));
        down->setFont(font);
        down->setStyleSheet(QLatin1String("border:2px groove gray;\n"
"border-radius:7px;\n"
"padding:2px 4px;color: rgb(255, 255, 0);"));
        hou = new QPushButton(centralwidget);
        hou->setObjectName(QStringLiteral("hou"));
        hou->setGeometry(QRect(260, 430, 50, 40));
        hou->setStyleSheet(QLatin1String("border:2px groove gray;\n"
"border-radius:7px;\n"
"padding:2px 4px;color: rgb(255, 255, 0);"));
        stop_or_continue = new QPushButton(centralwidget);
        stop_or_continue->setObjectName(QStringLiteral("stop_or_continue"));
        stop_or_continue->setGeometry(QRect(360, 430, 80, 40));
        stop_or_continue->setStyleSheet(QLatin1String("border:2px groove gray;\n"
"border-radius:7px;\n"
"padding:2px 4px;color: rgb(255, 255, 0);"));
        line = new QFrame(centralwidget);
        line->setObjectName(QStringLiteral("line"));
        line->setGeometry(QRect(0, 430, 800, 5));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        horizontalSlider = new QSlider(centralwidget);
        horizontalSlider->setObjectName(QStringLiteral("horizontalSlider"));
        horizontalSlider->setGeometry(QRect(0, 410, 800, 20));
        horizontalSlider->setOrientation(Qt::Horizontal);
        gechi = new QLabel(centralwidget);
        gechi->setObjectName(QStringLiteral("gechi"));
        gechi->setGeometry(QRect(65, 160, 550, 60));
        QFont font1;
        font1.setPointSize(16);
        gechi->setFont(font1);
        gechi->setStyleSheet(QStringLiteral("color: rgb(85, 255, 0);"));
        gechi->setAlignment(Qt::AlignHCenter|Qt::AlignTop);
        background = new QLabel(centralwidget);
        background->setObjectName(QStringLiteral("background"));
        background->setGeometry(QRect(0, 0, 800, 480));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(770, 170, 30, 40));
        pushButton->setStyleSheet(QLatin1String("border:2px groove gray;\n"
"border-radius:7px;\n"
"padding:2px 4px;"));
        music->setCentralWidget(centralwidget);
        background->raise();
        horizontalSlider->raise();
        qian->raise();
        up->raise();
        down->raise();
        hou->raise();
        stop_or_continue->raise();
        line->raise();
        gechi->raise();
        pushButton->raise();
        listWidget->raise();
        menubar = new QMenuBar(music);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 28));
        music->setMenuBar(menubar);
        statusbar = new QStatusBar(music);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        music->setStatusBar(statusbar);

        retranslateUi(music);

        QMetaObject::connectSlotsByName(music);
    } // setupUi

    void retranslateUi(QMainWindow *music)
    {
        music->setWindowTitle(QApplication::translate("music", "MainWindow", 0));
        qian->setText(QApplication::translate("music", ">>", 0));
        up->setText(QApplication::translate("music", "+", 0));
        down->setText(QApplication::translate("music", "-", 0));
        hou->setText(QApplication::translate("music", "<<", 0));
        stop_or_continue->setText(QApplication::translate("music", "STOP", 0));
        gechi->setText(QString());
        background->setText(QString());
        pushButton->setText(QApplication::translate("music", "<", 0));
    } // retranslateUi

};

namespace Ui {
    class music: public Ui_music {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MUSIC_H
